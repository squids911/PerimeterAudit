$ErrorActionPreference = "Stop"
$project = Join-Path $PSScriptRoot "PerimeterAudit.csproj"
$out = Join-Path $PSScriptRoot "publish"
if (!(Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw ".NET 8 SDK не найден. Установите .NET 8 SDK для Windows и повторите."
}
dotnet publish $project -c Release -r win-x64 --self-contained true `
  -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true `
  -p:EnableCompressionInSingleFile=true -o $out
if ($LASTEXITCODE -ne 0) { throw "Сборка завершилась с ошибкой." }
Write-Host ""
Write-Host "Готово: $out\PerimeterAudit.exe" -ForegroundColor Green
