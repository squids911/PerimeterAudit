using System.Net;
using System.Net.Sockets;
using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace PerimeterAudit;

public sealed class AuditEngine
{
    public async Task<List<PortResult>> ScanTcpAsync(string host, IEnumerable<int> ports, int timeoutMs,
        int concurrency, IProgress<string>? progress, CancellationToken token)
    {
        var results = new System.Collections.Concurrent.ConcurrentBag<PortResult>();
        using var gate = new SemaphoreSlim(concurrency);
        var tasks = ports.Distinct().Select(async port =>
        {
            await gate.WaitAsync(token);
            try
            {
                token.ThrowIfCancellationRequested();
                var r = await ProbeTcpAsync(host, port, timeoutMs, token);
                if (r.State == "open") results.Add(r);
                progress?.Report($"TCP/{port}: {r.State} {r.Service}");
            }
            finally { gate.Release(); }
        }).ToArray();
        await Task.WhenAll(tasks);
        return results.OrderBy(x => x.Port).ToList();
    }

    private static async Task<PortResult> ProbeTcpAsync(string host, int port, int timeoutMs, CancellationToken token)
    {
        var r = new PortResult { Protocol = "TCP", Port = port, State = "closed", Service = GuessService(port) };
        try
        {
            using var client = new TcpClient();
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(token);
            cts.CancelAfter(timeoutMs);
            await client.ConnectAsync(host, port, cts.Token);
            r.State = "open";
            r.Risk = RiskFor(port);
            r.Details = await TryBannerAsync(client, port, timeoutMs, token);
            if (port is 443 or 465 or 993 or 995 or 54446 or 54447 or 54449)
                r.Details += await TryTlsAsync(host, port, timeoutMs, token);
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested) { r.State = "filtered/timeout"; }
        catch (SocketException ex)
        {
            r.State = ex.SocketErrorCode == SocketError.ConnectionRefused ? "closed" : "filtered";
        }
        catch (Exception ex) { r.Details = ex.Message; }
        return r;
    }

    private static async Task<string> TryBannerAsync(TcpClient client, int port, int timeoutMs, CancellationToken token)
    {
        try
        {
            client.ReceiveTimeout = Math.Min(timeoutMs, 1500);
            client.SendTimeout = 1000;
            var stream = client.GetStream();
            byte[] request = port switch
            {
                80 or 800 or 54446 or 55414 or 55556 => Encoding.ASCII.GetBytes("HEAD / HTTP/1.0\r\nHost: audit\r\nConnection: close\r\n\r\n"),
                25 or 110 or 143 => Array.Empty<byte>(),
                22 or 23 or 2200 => Array.Empty<byte>(),
                _ => Array.Empty<byte>()
            };
            if (request.Length > 0) await stream.WriteAsync(request, token);
            var buffer = new byte[1024];
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(token);
            cts.CancelAfter(1200);
            int n = await stream.ReadAsync(buffer.AsMemory(0, buffer.Length), cts.Token);
            if (n <= 0) return "";
            var s = Encoding.ASCII.GetString(buffer, 0, n).Replace("\r", " ").Replace("\n", " ").Trim();
            return s.Length > 240 ? s[..240] : s;
        }
        catch { return ""; }
    }

    private static async Task<string> TryTlsAsync(string host, int port, int timeoutMs, CancellationToken token)
    {
        try
        {
            using var tcp = new TcpClient();
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(token);
            cts.CancelAfter(timeoutMs);
            await tcp.ConnectAsync(host, port, cts.Token);
            X509Certificate2? cert = null;
            using var ssl = new SslStream(tcp.GetStream(), false, (_, c, _, _) =>
            {
                if (c != null) cert = new X509Certificate2(c);
                return true; // Audit-only: collect certificate even if untrusted; do not send credentials.
            });
            await ssl.AuthenticateAsClientAsync(new SslClientAuthenticationOptions
            {
                TargetHost = host,
                EnabledSslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13,
                CertificateRevocationCheckMode = X509RevocationMode.NoCheck
            }, cts.Token);
            var text = $"TLS: {ssl.SslProtocol}; cipher: {ssl.CipherAlgorithm} {ssl.CipherStrength}";
            if (cert != null) text += $"; cert: {cert.Subject}; expires: {cert.NotAfter:yyyy-MM-dd}";
            return " | " + text;
        }
        catch (Exception ex) { return $" | TLS probe: {ex.GetType().Name}"; }
    }

    public async Task<List<PortResult>> ScanUdpAsync(string host, IEnumerable<int> ports, int timeoutMs,
        IProgress<string>? progress, CancellationToken token)
    {
        var output = new List<PortResult>();
        foreach (int port in ports.Distinct())
        {
            token.ThrowIfCancellationRequested();
            var r = new PortResult { Protocol = "UDP", Port = port, State = "open|filtered", Service = GuessService(port),
                Risk = RiskFor(port), Details = "Нет ответа на универсальный UDP-запрос; состояние open|filtered неоднозначно." };
            try
            {
                using var udp = new UdpClient();
                udp.Client.ReceiveTimeout = timeoutMs;
                udp.Connect(host, port);
                byte[] payload = port switch
                {
                    123 => new byte[] { 0x23,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
                    53 => new byte[] { 0x00,0x01,0x01,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x07,0x65,0x78,0x61,0x6d,0x70,0x6c,0x65,0x03,0x63,0x6f,0x6d,0x00,0x00,0x01,0x00,0x01 },
                    _ => Array.Empty<byte>()
                };
                await udp.SendAsync(payload, token);
                using var cts = CancellationTokenSource.CreateLinkedTokenSource(token);
                cts.CancelAfter(timeoutMs);
                var response = await udp.ReceiveAsync(cts.Token);
                r.State = "open";
                r.Details = $"Получен UDP-ответ ({response.Buffer.Length} байт).";
                if (port == 123 && response.Buffer.Length >= 4) r.Details += " NTP-ответ.";
                if (port == 53) r.Details += " DNS-ответ.";
            }
            catch (OperationCanceledException) { }
            catch (SocketException ex)
            {
                if (ex.SocketErrorCode == SocketError.ConnectionReset) r.State = "closed";
                else r.Details = $"UDP probe: {ex.SocketErrorCode}; результат может быть неоднозначным.";
            }
            output.Add(r);
            progress?.Report($"UDP/{port}: {r.State}");
        }
        return output;
    }

    public static string GuessService(int p) => p switch
    {
        21=>"FTP",22=>"SSH",23=>"Telnet?",25=>"SMTP",53=>"DNS",67=>"DHCP",68=>"DHCP",
        80=>"HTTP",110=>"POP3",123=>"NTP",143=>"IMAP",161=>"SNMP",443=>"HTTPS",
        465=>"SMTPS",500=>"IPsec/IKE",514=>"Syslog",520=>"RIP",800=>"Web UI?",993=>"IMAPS",
        995=>"POP3S",1194=>"OpenVPN",1701=>"L2TP",1900=>"UPnP",2000=>"MikroTik bandwidth-test?",
        3389=>"RDP",4500=>"IPsec NAT-T",5060=>"SIP",51820=>"WireGuard?",6430=>"Unknown",
        8291=>"MikroTik Winbox?",8292=>"Unknown",8729=>"MikroTik API-SSL?",10051=>"Zabbix trapper?",
        21115 or 21116 or 21117 or 21118 or 21119=>"Remote access service?",54446=>"Grafana?",
        54447 or 54449=>"SSH?",55414=>"UrBackup?",_=>"Unknown"
    };

    public static string RiskFor(int p) => p switch
    {
        23 or 800 or 8291 or 8292 or 8729 or 2000 => "Высокий: управление/служебный доступ",
        1723 or 3389 or 10051 or 54446 or 55414 => "Повышенный: проверить необходимость",
        110 or 143 or 21 => "Проверить шифрование",
        _ => "Проверить назначение"
    };
}
