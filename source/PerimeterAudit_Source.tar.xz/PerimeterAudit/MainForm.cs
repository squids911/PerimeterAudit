using System.Net;
using System.Text.Json;

namespace PerimeterAudit;

public sealed class MainForm : Form
{
    TextBox target = new() { Text = "mail.csl.by", Width = 230 };
    TextBox tcpPorts = new() { Text = "1-1024,1723,2000,3389,6430,8000-9000,10051,21115-21119,40101,52400,53389,54446-54449,55413-55415,55555-55556,60006,63233", Width = 620 };
    TextBox udpPorts = new() { Text = "53,67,68,69,123,137,138,161,162,500,514,520,623,1194,1701,1900,4500,5060,5353,10000,51820", Width = 620 };
    NumericUpDown timeout = new() { Minimum = 300, Maximum = 10000, Value = 1200, Increment = 100, Width = 90 };
    NumericUpDown concurrency = new() { Minimum = 1, Maximum = 200, Value = 80, Width = 90 };
    CheckBox doTcp = new() { Text = "TCP", Checked = true, AutoSize = true };
    CheckBox doUdp = new() { Text = "UDP (предварительно)", Checked = true, AutoSize = true };
    Button start = new() { Text = "Начать аудит", AutoSize = true, Height = 34 };
    Button cancel = new() { Text = "Остановить", AutoSize = true, Height = 34, Enabled = false };
    Button export = new() { Text = "Экспорт HTML", AutoSize = true, Height = 34, Enabled = false };
    Button csv = new() { Text = "Экспорт CSV", AutoSize = true, Height = 34, Enabled = false };
    ProgressBar bar = new() { Dock = DockStyle.Fill, Height = 18 };
    Label status = new() { Text = "Готово", AutoSize = true };
    DataGridView grid = new() { Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, SelectionMode = DataGridViewSelectionMode.FullRowSelect };
    TextBox log = new() { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Height = 100 };
    CancellationTokenSource? cts;
    ScanResult? last;
    readonly AuditEngine engine = new();

    public MainForm()
    {
        Text = "Perimeter Audit — аудит внешнего периметра";
        Width = 1180; Height = 780; MinimumSize = new Size(950, 650);
        StartPosition = FormStartPosition.CenterScreen;
        var top = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(12), ColumnCount = 4 };
        top.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        AddRow(top, "Цель (IP/домен):", target, "Таймаут, мс:", timeout);
        AddRow(top, "TCP-порты:", tcpPorts, "Параллельность:", concurrency);
        AddRow(top, "UDP-порты:", udpPorts, "Режим:", new FlowLayoutPanel { AutoSize=true, Controls={doTcp,doUdp} });
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(12,0,12,8) };
        buttons.Controls.AddRange(new Control[] { start, cancel, export, csv, status });
        var split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal, SplitterDistance = 490 };
        grid.Columns.Add("Protocol", "Протокол"); grid.Columns.Add("Port", "Порт"); grid.Columns.Add("State", "Состояние");
        grid.Columns.Add("Service", "Предполагаемая служба"); grid.Columns.Add("Risk", "Заметка / приоритет"); grid.Columns.Add("Details", "Ответ / детали");
        split.Panel1.Controls.Add(grid); split.Panel2.Controls.Add(log);
        Controls.Add(split); Controls.Add(buttons); Controls.Add(top);
        start.Click += async (_,_) => await RunAudit();
        cancel.Click += (_,_) => cts?.Cancel();
        export.Click += (_,_) => ExportHtml();
        csv.Click += (_,_) => ExportCsv();
        grid.DataBindingComplete += (_,_) => { foreach (DataGridViewColumn c in grid.Columns) c.SortMode = DataGridViewColumnSortMode.Automatic; };
        Append("Важно: сканируйте только системы, которыми вы владеете или на проверку которых у вас есть разрешение.");
    }

    static void AddRow(TableLayoutPanel p, string label, Control input, string label2, Control input2)
    {
        int row = p.RowCount++; p.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        p.Controls.Add(new Label { Text=label, AutoSize=true, Anchor=AnchorStyles.Left, Padding=new Padding(0,7,8,0) },0,row);
        p.Controls.Add(input,1,row);
        p.Controls.Add(new Label { Text=label2, AutoSize=true, Anchor=AnchorStyles.Left, Padding=new Padding(12,7,8,0) },2,row);
        p.Controls.Add(input2,3,row);
    }

    async Task RunAudit()
    {
        if (!doTcp.Checked && !doUdp.Checked) { MessageBox.Show("Выберите TCP или UDP."); return; }
        List<int> tPorts, uPorts;
        try { tPorts = ParsePorts(tcpPorts.Text); uPorts = ParsePorts(udpPorts.Text); }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Ошибка списка портов"); return; }
        string host = target.Text.Trim();
        if (host.Length == 0) return;
        start.Enabled=false; cancel.Enabled=true; export.Enabled=false; csv.Enabled=false;
        grid.DataSource=null; log.Clear(); bar.Value=0;
        bar.Maximum = Math.Max(1, (doTcp.Checked ? tPorts.Count : 0) + (doUdp.Checked ? uPorts.Count : 0));
        int completed = 0;
        cts=new CancellationTokenSource();
        last = new ScanResult { Target=host };
        var progress = new Progress<string>(s =>
        {
            status.Text=s;
            Append(s);
            completed++;
            bar.Value = Math.Min(completed, bar.Maximum);
        });
        try
        {
            IPAddress[] addresses = await Dns.GetHostAddressesAsync(host);
            if (addresses.Length == 0) throw new Exception("Не удалось разрешить имя.");
            Append($"Цель: {host}; адрес: {string.Join(", ", addresses.Select(x=>x.ToString()))}");
            if (doTcp.Checked)
            {
                Append($"TCP: проверка {tPorts.Count} портов...");
                last.Ports.AddRange(await engine.ScanTcpAsync(host,tPorts,(int)timeout.Value,(int)concurrency.Value,progress,cts.Token));
            }
            if (doUdp.Checked)
            {
                Append($"UDP: проверка {uPorts.Count} портов. Отсутствие ответа не означает, что порт закрыт.");
                last.Ports.AddRange(await engine.ScanUdpAsync(host,uPorts,(int)timeout.Value,progress,cts.Token));
            }
            status.Text="Завершено";
            Append($"Готово. Найдено записей: {last.Ports.Count}");
        }
        catch (OperationCanceledException) { status.Text="Остановлено"; Append("Сканирование остановлено пользователем."); }
        catch (Exception ex) { status.Text="Ошибка"; Append("Ошибка: "+ex.Message); MessageBox.Show(ex.Message); }
        finally
        {
            grid.DataSource = last.Ports.Select(x=>new { x.Protocol,x.Port,x.State,x.Service,x.Risk,x.Details }).ToList();
            start.Enabled=true; cancel.Enabled=false; export.Enabled=last.Ports.Count>0; csv.Enabled=last.Ports.Count>0;
            cts.Dispose(); cts=null;
            SaveHistory(last);
        }
    }

    static List<int> ParsePorts(string input)
    {
        var set = new SortedSet<int>();
        foreach (var raw in input.Split(',',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries))
        {
            if (raw.Contains('-'))
            {
                var a=raw.Split('-',2); if(a.Length!=2 || !int.TryParse(a[0],out int lo) || !int.TryParse(a[1],out int hi) || lo<1 || hi>65535 || lo>hi || hi-lo>20000) throw new Exception($"Некорректный диапазон: {raw}");
                for(int p=lo;p<=hi;p++) set.Add(p);
            }
            else if(int.TryParse(raw,out int p) && p>=1 && p<=65535) set.Add(p);
            else throw new Exception($"Некорректный порт: {raw}");
        }
        if(set.Count==0) throw new Exception("Список портов пуст.");
        return set.ToList();
    }

    void Append(string s) { if (log.IsDisposed) return; log.AppendText($"[{DateTime.Now:HH:mm:ss}] {s}{Environment.NewLine}"); }
    static string HistoryPath => Path.Combine(AppContext.BaseDirectory,"history");
    static void SaveHistory(ScanResult result)
    {
        try { Directory.CreateDirectory(HistoryPath); File.WriteAllText(Path.Combine(HistoryPath,$"{DateTime.Now:yyyyMMdd-HHmmss}.json"),JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true})); } catch {}
    }

    void ExportHtml()
    {
        if(last==null) return;
        using var d=new SaveFileDialog{Filter="HTML report|*.html",FileName=$"PerimeterAudit-{DateTime.Now:yyyyMMdd-HHmm}.html"};
        if(d.ShowDialog()!=DialogResult.OK)return;
        var rows=string.Join("",last.Ports.Select(p=>$"<tr><td>{WebUtility.HtmlEncode(p.Protocol)}</td><td>{p.Port}</td><td>{WebUtility.HtmlEncode(p.State)}</td><td>{WebUtility.HtmlEncode(p.Service)}</td><td>{WebUtility.HtmlEncode(p.Risk)}</td><td>{WebUtility.HtmlEncode(p.Details)}</td></tr>"));
        File.WriteAllText(d.FileName,$"<!doctype html><meta charset='utf-8'><title>Perimeter Audit</title><style>body{{font:14px Segoe UI;margin:30px}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #ccc;padding:7px;text-align:left}}th{{background:#eee}}</style><h1>Perimeter Audit</h1><p>Цель: {WebUtility.HtmlEncode(last.Target)} | Дата: {last.Started}</p><p>Результаты являются предварительной технической инвентаризацией, а не подтверждением уязвимости.</p><table><tr><th>Протокол</th><th>Порт</th><th>Состояние</th><th>Служба</th><th>Заметка</th><th>Детали</th></tr>{rows}</table>");
        MessageBox.Show("HTML-отчёт сохранён.");
    }
    void ExportCsv()
    {
        if(last==null)return;
        using var d=new SaveFileDialog{Filter="CSV|*.csv",FileName=$"PerimeterAudit-{DateTime.Now:yyyyMMdd-HHmm}.csv"};
        if(d.ShowDialog()!=DialogResult.OK)return;
        var lines=new List<string>{"Protocol,Port,State,Service,Risk,Details"};
        lines.AddRange(last.Ports.Select(p=>string.Join(",",new[]{p.Protocol,p.Port.ToString(),p.State,p.Service,p.Risk,p.Details}.Select(CsvEscape))));
        File.WriteAllText(d.FileName,string.Join(Environment.NewLine,lines),new System.Text.UTF8Encoding(true));
        MessageBox.Show("CSV сохранён.");
    }
    static string CsvEscape(string s)=>"\""+s.Replace("\"","\"\"")+"\"";
}
