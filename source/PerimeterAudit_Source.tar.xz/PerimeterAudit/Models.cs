namespace PerimeterAudit;

public sealed class ScanResult
{
    public DateTime Started { get; set; } = DateTime.Now;
    public string Target { get; set; } = "";
    public List<PortResult> Ports { get; set; } = new();
    public List<string> Notes { get; set; } = new();
}
public sealed class PortResult
{
    public string Protocol { get; set; } = "TCP";
    public int Port { get; set; }
    public string State { get; set; } = "";
    public string Service { get; set; } = "";
    public string Details { get; set; } = "";
    public string Risk { get; set; } = "Информация";
}
