#define MyAppName "Perimeter Audit"
#ifndef MyAppVersion
  #define MyAppVersion "1.0.0"
#endif
#define MyAppPublisher "CSL"
#define MyAppExeName "PerimeterAudit.exe"

[Setup]
AppId={{C7D90F4A-5D31-4A84-9A82-62E0A6F6A9D3}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Perimeter Audit
DefaultGroupName={#MyAppName}
OutputBaseFilename=PerimeterAudit-Setup
OutputDir=..
ArchitecturesInstallIn64BitMode=x64
ArchitecturesAllowed=x64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\{#MyAppExeName}
PrivilegesRequired=admin

[Files]
Source: "..\publish\PerimeterAudit.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Perimeter Audit"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Perimeter Audit"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Дополнительные значки:"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Запустить Perimeter Audit"; Flags: postinstall nowait skipifsilent
