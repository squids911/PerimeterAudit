#ifndef MyAppVersion
  #define MyAppVersion "1.0.0"
#endif

[Setup]
AppId={{B9B7E7E1-9C50-4A72-9B2D-5F5A1A70E9C1}
AppName=Perimeter Audit
AppVersion={#MyAppVersion}
AppPublisher=CSL
DefaultDirName={autopf}\Perimeter Audit
DefaultGroupName=Perimeter Audit
OutputDir=..\..\dist
OutputBaseFilename=PerimeterAudit-Setup
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\PerimeterAudit.exe

[Files]
Source: "..\publish\PerimeterAudit.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Perimeter Audit"; Filename: "{app}\PerimeterAudit.exe"
Name: "{autodesktop}\Perimeter Audit"; Filename: "{app}\PerimeterAudit.exe"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Дополнительные значки:"

[Run]
Filename: "{app}\PerimeterAudit.exe"; Description: "Запустить Perimeter Audit"; Flags: nowait postinstall skipifsilent
