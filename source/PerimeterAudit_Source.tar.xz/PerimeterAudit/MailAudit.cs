using System.Net;
using System.Net.NetworkInformation;
using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Net.Sockets;
using System.Text;

namespace PerimeterAudit;

public sealed class MailAudit
{
    private readonly string[] _selectors = { "default", "selector1", "selector2", "google", "s1", "s2", "mail", "dk", "k1", "k2", "smtp", "email", "mandrill", "everlytickey1", "everlytickey2", "protonmail", "zoho", "mx1", "mx2" };
    private readonly string[] _ipLists = { "zen.spamhaus.org", "bl.spamcop.net", "b.barracudacentral.org" };
    private readonly string[] _domainLists = { "dbl.spamhaus.org", "multi.surbl.org" };

    public async Task<List<PortResult>> RunAsync(string input, string extraSelectors, int timeoutMs, IProgress<string>? progress, CancellationToken token)
    {
        var rows = new List<PortResult>();
        string domain = input.Trim().TrimEnd('.');
        if (IPAddress.TryParse(domain, out _))
        {
            rows.Add(Row("DNS", "IP в поле цели", "Информация", "Указан IP-адрес", domain, "Для SPF/DMARC/DKIM/MX укажите доменное имя."));
            await CheckIpAsync(domain, rows, progress, token);
            return rows;
        }

        IPAddress[] ips;
        try { ips = await Dns.GetHostAddressesAsync(domain, token); }
        catch (Exception ex) { ips = Array.Empty<IPAddress>(); rows.Add(Row("DNS", "A/AAAA", "Ошибка", "Разрешение имени", domain, ex.Message)); }
        rows.Add(Row("DNS", "A/AAAA", ips.Length > 0 ? "Найдено" : "Не найдено", "Адреса домена", domain, ips.Length > 0 ? string.Join(", ", ips.Select(x => x.ToString())) : "A/AAAA записи не получены."));

        var mx = await QueryAsync(domain, 15, timeoutMs, token);
        var mxHosts = mx.Where(x => x.Type == 15).Select(x => x.Text).ToList();
        rows.Add(Row("DNS", "MX", mxHosts.Count > 0 ? "Найдено" : "Не найдено", "Почтовые серверы", domain, mxHosts.Count > 0 ? string.Join("; ", mxHosts) : "MX-записи отсутствуют или DNS-запрос не получил ответ."));

        var txt = await QueryAsync(domain, 16, timeoutMs, token);
        var spf = txt.Where(x => x.Type == 16 && x.Text.StartsWith("v=spf1", StringComparison.OrdinalIgnoreCase)).Select(x => x.Text).ToList();
        rows.Add(Row("DNS", "SPF", spf.Count > 0 ? "Найдено" : "Не найдено", "Sender Policy Framework", domain, spf.Count > 0 ? string.Join(" | ", spf) : "SPF TXT-запись не обнаружена."));

        var dmarc = await QueryAsync("_dmarc." + domain, 16, timeoutMs, token);
        var dmarcTxt = dmarc.Where(x => x.Type == 16 && x.Text.StartsWith("v=DMARC1", StringComparison.OrdinalIgnoreCase)).Select(x => x.Text).ToList();
        string dmarcState = dmarcTxt.Count == 0 ? "Не найдено" : dmarcTxt.Any(x => x.Contains("p=reject", StringComparison.OrdinalIgnoreCase)) ? "Строгая политика" : dmarcTxt.Any(x => x.Contains("p=quarantine", StringComparison.OrdinalIgnoreCase)) ? "Карантин" : "Мониторинг / слабая политика";
        rows.Add(Row("DNS", "DMARC", dmarcTxt.Count > 0 ? dmarcState : "Не найдено", "Domain-based Message Authentication", "_dmarc." + domain, dmarcTxt.Count > 0 ? string.Join(" | ", dmarcTxt) : "DMARC TXT-запись не обнаружена."));

        var selectors = _selectors.Concat(extraSelectors.Split(new[] { ',', ';', ' ', '\r', '\n', '\t' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)).Distinct(StringComparer.OrdinalIgnoreCase);
        int found = 0;
        foreach (var selector in selectors)
        {
            token.ThrowIfCancellationRequested();
            string name = selector + "._domainkey." + domain;
            var dkim = await QueryAsync(name, 16, timeoutMs, token);
            var records = dkim.Where(x => x.Type == 16 && x.Text.Contains("p=", StringComparison.OrdinalIgnoreCase)).Select(x => x.Text).ToList();
            if (records.Count > 0)
            {
                found++;
                rows.Add(Row("DNS", "DKIM", "Найдено", "DKIM selector " + selector, name, string.Join(" | ", records)));
            }
        }
        rows.Add(Row("DNS", "DKIM", found > 0 ? "Найдены селекторы" : "Не обнаружено", "Проверка распространённых DKIM selector", domain, found > 0 ? $"Найдено селекторов: {found}. Проверялись стандартные и указанные вручную значения." : "Проверены распространённые селекторы и пользовательский список. Это не доказывает отсутствие DKIM: неизвестный selector нужно добавить вручную."));

        foreach (var ip in ips.Where(x => x.AddressFamily == AddressFamily.InterNetwork))
        {
            token.ThrowIfCancellationRequested();
            await CheckIpAsync(ip.ToString(), rows, progress, token);
        }
        await CheckDomainListsAsync(domain, rows, progress, token);
        await CheckMailEndpointsAsync(mxHosts, timeoutMs, rows, progress, token);
        return rows;
    }

    private async Task CheckIpAsync(string ip, List<PortResult> rows, IProgress<string>? progress, CancellationToken token)
    {
        if (!IPAddress.TryParse(ip, out var addr) || addr.AddressFamily != AddressFamily.InterNetwork) return;
        string reversed = string.Join('.', addr.GetAddressBytes().Reverse());
        try
        {
            var ptr = await Dns.GetHostEntryAsync(addr, token);
            rows.Add(Row("DNS", "PTR", "Найдено", "Обратная DNS-запись", ip, string.Join(", ", ptr.Aliases.Append(ptr.HostName).Where(x => !string.IsNullOrWhiteSpace(x)))));
        }
        catch { rows.Add(Row("DNS", "PTR", "Не найдено", "Обратная DNS-запись", ip, "PTR-запись не обнаружена.")); }
        foreach (var list in _ipLists)
        {
            token.ThrowIfCancellationRequested();
            var result = await QueryAsync(reversed + "." + list, 1, 2500, token);
            var a = result.Where(x => x.Type == 1).Select(x => x.Text).ToList();
            rows.Add(Row("DNSBL", "IP", a.Count > 0 ? "В списке" : "Не обнаружен", list, ip, a.Count > 0 ? "DNSBL ответ: " + string.Join(", ", a) : "Нет положительного ответа. Возможны ограничения/ошибки DNSBL-запроса."));
            progress?.Report($"DNSBL IP {ip}: {list} — {(a.Count > 0 ? "match" : "no match")}");
        }
    }

    private async Task CheckDomainListsAsync(string domain, List<PortResult> rows, IProgress<string>? progress, CancellationToken token)
    {
        foreach (var list in _domainLists)
        {
            token.ThrowIfCancellationRequested();
            var result = await QueryAsync(domain + "." + list, 1, 2500, token);
            var a = result.Where(x => x.Type == 1).Select(x => x.Text).ToList();
            rows.Add(Row("DNSBL", "Домен", a.Count > 0 ? "В списке" : "Не обнаружен", list, domain, a.Count > 0 ? "DNSBL ответ: " + string.Join(", ", a) : "Нет положительного ответа. Некоторые DNSBL ограничивают запросы с публичных резолверов."));
            progress?.Report($"DNSBL domain {domain}: {list}");
        }
    }

    private async Task CheckMailEndpointsAsync(List<string> mx, int timeout, List<PortResult> rows, IProgress<string>? progress, CancellationToken token)
    {
        foreach (var item in mx)
        {
            string host = item.Contains(' ') ? item[(item.IndexOf(' ') + 1)..].TrimEnd('.') : item.TrimEnd('.');
            foreach (int port in new[] { 25, 465, 587, 110, 143, 993, 995 })
            {
                token.ThrowIfCancellationRequested();
                try
                {
                    using var tcp = new TcpClient();
                    using var cts = CancellationTokenSource.CreateLinkedTokenSource(token); cts.CancelAfter(timeout);
                    await tcp.ConnectAsync(host, port, cts.Token);
                    string greeting = "TCP connected";
                    Stream stream = tcp.GetStream();
                    if (port is 465 or 993 or 995)
                    {
                        var tls = await UpgradeTlsAsync(stream, host, cts.Token);
                        stream = tls.Stream;
                        greeting = tls.Info;
                    }
                    else
                    {
                        greeting = await ReadLineAsync(stream, Math.Min(timeout, 1800), token) ?? "TCP connected; greeting отсутствует";
                        if (port is 25 or 587)
                        {
                            await WriteLineAsync(stream, "EHLO perimeter-audit.local", token);
                            string ehlo = await ReadMultilineAsync(stream, timeout, token);
                            greeting += " | EHLO: " + Compact(ehlo, 350);
                            if (ehlo.Contains("STARTTLS", StringComparison.OrdinalIgnoreCase))
                            {
                                await WriteLineAsync(stream, "STARTTLS", token);
                                string reply = await ReadLineAsync(stream, timeout, token) ?? "no reply";
                                if (reply.StartsWith("220", StringComparison.Ordinal))
                                {
                                    var tls = await UpgradeTlsAsync(stream, host, cts.Token);
                                    greeting += " | STARTTLS: " + tls.Info;
                                }
                                else greeting += " | STARTTLS reply: " + reply;
                            }
                            else greeting += " | STARTTLS не объявлен сервером";
                        }
                        else if (port == 110)
                        {
                            await WriteLineAsync(stream, "CAPA", token);
                            string caps = await ReadDotBlockAsync(stream, timeout, token);
                            greeting += " | CAPA: " + Compact(caps, 250);
                            if (caps.Contains("STLS", StringComparison.OrdinalIgnoreCase))
                            {
                                await WriteLineAsync(stream, "STLS", token);
                                string reply = await ReadLineAsync(stream, timeout, token) ?? "no reply";
                                if (reply.StartsWith("+OK", StringComparison.OrdinalIgnoreCase))
                                {
                                    var tls = await UpgradeTlsAsync(stream, host, cts.Token);
                                    greeting += " | STLS: " + tls.Info;
                                }
                                else greeting += " | STLS reply: " + reply;
                            }
                            else greeting += " | STLS не объявлен сервером";
                        }
                        else if (port == 143)
                        {
                            await WriteLineAsync(stream, "a001 CAPABILITY", token);
                            string caps = await ReadUntilAsync(stream, "a001 ", timeout, token);
                            greeting += " | CAPABILITY: " + Compact(caps, 250);
                            if (caps.Contains("STARTTLS", StringComparison.OrdinalIgnoreCase))
                            {
                                await WriteLineAsync(stream, "a002 STARTTLS", token);
                                string reply = await ReadLineAsync(stream, timeout, token) ?? "no reply";
                                if (reply.StartsWith("a002 OK", StringComparison.OrdinalIgnoreCase))
                                {
                                    var tls = await UpgradeTlsAsync(stream, host, cts.Token);
                                    greeting += " | STARTTLS: " + tls.Info;
                                }
                                else greeting += " | STARTTLS reply: " + reply;
                            }
                            else greeting += " | STARTTLS не объявлен сервером";
                        }
                    }
                    rows.Add(Row("MAIL", port.ToString(), "Доступен", port switch { 25 => "SMTP", 465 => "SMTPS", 587 => "Submission", 110 => "POP3", 143 => "IMAP", 993 => "IMAPS", _ => "POP3S" }, host, greeting));
                }
                catch (OperationCanceledException) when (token.IsCancellationRequested) { throw; }
                catch (Exception ex) when (ex is SocketException or OperationCanceledException or IOException or AuthenticationException)
                {
                    rows.Add(Row("MAIL", port.ToString(), "Недоступен / ошибка", "Mail service", host, ex is SocketException se ? se.SocketErrorCode.ToString() : ex.GetType().Name + ": " + ex.Message));
                }
                progress?.Report($"Проверка почтового узла {host}:{port}");
            }
        }
    }

    private static async Task<(Stream Stream, string Info)> UpgradeTlsAsync(Stream stream, string host, CancellationToken token)
    {
        X509Certificate2? cert = null;
        var ssl = new SslStream(stream, false, (_, certificate, _, _) =>
        {
            if (certificate != null) cert = new X509Certificate2(certificate);
            return true; // Только аудит: сертификат собирается, проверка доверия не блокирует диагностику.
        });
        await ssl.AuthenticateAsClientAsync(new SslClientAuthenticationOptions
        {
            TargetHost = host,
            EnabledSslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13,
            CertificateRevocationCheckMode = X509RevocationMode.NoCheck
        }, token);
        string info = $"TLS {ssl.SslProtocol}; {ssl.CipherAlgorithm}/{ssl.CipherStrength}";
        if (cert != null) info += $"; сертификат: {cert.Subject}; до {cert.NotAfter:yyyy-MM-dd}; SAN: {cert.GetNameInfo(X509NameType.DnsName, false)}";
        return (ssl, info);
    }

    private static async Task WriteLineAsync(Stream stream, string line, CancellationToken token)
    {
        byte[] data = Encoding.ASCII.GetBytes(line + "\r\n");
        await stream.WriteAsync(data, token);
    }

    private static async Task<string?> ReadLineAsync(Stream stream, int timeout, CancellationToken token)
    {
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(token); cts.CancelAfter(timeout);
        var bytes = new List<byte>(); var one = new byte[1];
        while (bytes.Count < 2048)
        {
            int n = await stream.ReadAsync(one, cts.Token); if (n == 0) break;
            if (one[0] == 10) break; if (one[0] != 13) bytes.Add(one[0]);
        }
        return bytes.Count == 0 ? null : Encoding.ASCII.GetString(bytes.ToArray());
    }

    private static async Task<string> ReadMultilineAsync(Stream stream, int timeout, CancellationToken token)
    {
        var lines = new List<string>();
        for (int i = 0; i < 40; i++)
        {
            var line = await ReadLineAsync(stream, timeout, token); if (line == null) break; lines.Add(line);
            if (line.Length >= 4 && line[3] == ' ') break;
            if (line.StartsWith("250 ", StringComparison.Ordinal)) break;
        }
        return string.Join("; ", lines);
    }

    private static async Task<string> ReadDotBlockAsync(Stream stream, int timeout, CancellationToken token)
    {
        var lines = new List<string>();
        for (int i = 0; i < 40; i++)
        {
            var line = await ReadLineAsync(stream, timeout, token); if (line == null) break; lines.Add(line);
            if (line == ".") break;
        }
        return string.Join("; ", lines);
    }

    private static async Task<string> ReadUntilAsync(Stream stream, string terminator, int timeout, CancellationToken token)
    {
        var lines = new List<string>();
        for (int i = 0; i < 40; i++)
        {
            var line = await ReadLineAsync(stream, timeout, token); if (line == null) break; lines.Add(line);
            if (line.StartsWith(terminator, StringComparison.OrdinalIgnoreCase)) break;
        }
        return string.Join("; ", lines);
    }

    private static string Compact(string value, int max) => value.Length > max ? value[..max] + "…" : value;

    private sealed record DnsRecord(ushort Type, string Text);
    private static async Task<List<DnsRecord>> QueryAsync(string name, ushort type, int timeout, CancellationToken token)
    {
        var resolver = NetworkInterface.GetAllNetworkInterfaces().Where(n => n.OperationalStatus == OperationalStatus.Up).SelectMany(n => n.GetIPProperties().DnsAddresses).FirstOrDefault(a => a.AddressFamily == AddressFamily.InterNetwork);
        if (resolver == null) return new();
        try
        {
            ushort id = (ushort)Random.Shared.Next(1, 65535);
            using var udp = new UdpClient(resolver.AddressFamily);
            udp.Connect(resolver, 53);
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(token); cts.CancelAfter(timeout);
            var packet = BuildQuery(id, name, type);
            await udp.SendAsync(packet, cts.Token);
            var response = await udp.ReceiveAsync(cts.Token);
            return ParseResponse(response.Buffer, id);
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested) { throw; }
        catch { return new(); }
    }

    private static byte[] BuildQuery(ushort id, string name, ushort type)
    {
        using var ms = new MemoryStream(); using var bw = new BinaryWriter(ms);
        bw.Write((byte)(id >> 8)); bw.Write((byte)id); bw.Write((byte)1); bw.Write((byte)0); bw.Write((byte)0); bw.Write((byte)1); bw.Write(new byte[6]);
        foreach (var label in name.TrimEnd('.').Split('.')) { var b = Encoding.ASCII.GetBytes(label); bw.Write((byte)b.Length); bw.Write(b); }
        bw.Write((byte)0); bw.Write((byte)(type >> 8)); bw.Write((byte)type); bw.Write((byte)0); bw.Write((byte)1);
        return ms.ToArray();
    }

    private static List<DnsRecord> ParseResponse(byte[] b, ushort id)
    {
        var output = new List<DnsRecord>(); if (b.Length < 12 || ((b[0] << 8) | b[1]) != id) return output;
        int qd = (b[4] << 8) | b[5], an = (b[6] << 8) | b[7], p = 12;
        for (int i = 0; i < qd; i++) { ReadName(b, ref p); p += 4; }
        for (int i = 0; i < an && p + 10 <= b.Length; i++)
        {
            ReadName(b, ref p); if (p + 10 > b.Length) break;
            ushort type = (ushort)((b[p] << 8) | b[p + 1]); ushort len = (ushort)((b[p + 8] << 8) | b[p + 9]); p += 10;
            if (p + len > b.Length) break;
            string value = "";
            if (type == 1 && len == 4) value = new IPAddress(b.Skip(p).Take(4).ToArray()).ToString();
            else if (type == 16) { int q = p, end = p + len; var parts = new List<string>(); while (q < end) { int n = b[q++]; if (q + n > end) break; parts.Add(Encoding.UTF8.GetString(b, q, n)); q += n; } value = string.Concat(parts); }
            else if (type == 15 && len >= 3) { int q = p + 2; string exchange = ReadName(b, ref q); value = ((b[p] << 8) | b[p + 1]) + " " + exchange; }
            if (value.Length > 0) output.Add(new DnsRecord(type, value));
            p += len;
        }
        return output;
    }

    private static string ReadName(byte[] b, ref int p)
    {
        var labels = new List<string>(); int end = -1, guard = 0;
        while (p < b.Length && guard++ < 128)
        {
            int n = b[p++]; if (n == 0) break;
            if ((n & 0xC0) == 0xC0) { if (p >= b.Length) break; int offset = ((n & 0x3F) << 8) | b[p++]; if (end < 0) end = p; p = offset; continue; }
            if (p + n > b.Length) break; labels.Add(Encoding.ASCII.GetString(b, p, n)); p += n;
        }
        if (end >= 0) p = end;
        return string.Join('.', labels);
    }

    private static PortResult Row(string protocol, string port, string state, string service, string risk, string details) => new() { Protocol = protocol, Port = int.TryParse(port, out var n) ? n : 0, State = state, Service = service, Risk = risk, Details = details };
}
